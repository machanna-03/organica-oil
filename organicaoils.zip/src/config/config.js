export const config = {
  // getMyCollege: "http://82.112.230.5:8095",
  getMyCollege: "https://api.comebackorganic.com",
  imageUpload: "https://image-upload.seomitra.com",
  cookieName: "org_user",
  sessionCookie: "org_sess",
};